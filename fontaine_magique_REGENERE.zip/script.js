
function dropCoin(amount) {
  alert('Tu as lancé une pièce de ' + amount + '€ dans la fontaine ✨');
}
